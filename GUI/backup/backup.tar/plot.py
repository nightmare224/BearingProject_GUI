import plotly.express as px
import pandas as pd
import numpy as np

fig = px.line(data, title = 'Time Domain')
